﻿using UnityEngine;

[CreateAssetMenu(menuName = "GameObject/Tag")]
public class Tag : ScriptableObject
{
}